🦾 Robot Arm Control Panel – Task 1
This project is a Flutter + PHP application for controlling and saving poses of a robotic arm with 4 motors. It provides a mobile app with sliders to set motor angles and buttons to save, run, and reset poses.

📌 Features
✅ Control 4 motors with sliders
✅ Save poses to MySQL database
✅ Run saved poses (updates status)
✅ Reset all motors to default (90°)
✅ View all saved poses with real-time updates

🛠️ 1. Setup
Flutter App
1.	Install Flutter SDK and Android Studio
2.	Create project:
flutter create run_pose_app
3.	Add dependencies in pubspec.yaml:
yaml
CopyEdit
http: ^1.4.0
sqflite: ^2.0.0+4
path_provider: ^2.0.1
4.	Implement UI and logic in main.dart (sliders, save, run, reset)

Database
1.	Open phpMyAdmin via http://localhost/phpmyadmin
2.	Create database run_pose_db
3.	Create table poses:
CREATE TABLE poses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    motor1 INT NOT NULL,
    motor2 INT NOT NULL,
    motor3 INT NOT NULL,
    motor4 INT NOT NULL,
    status TINYINT DEFAULT 0
);

Backend PHP Files
📂 Place these in xampp/htdocs/run_pose/:
•	save_pose.php → Saves motor angles to DB
•	get_run_pose.php → Fetches saved poses
•	update_status.php → Updates pose status
Test APIs with curl:
curl -X POST -d "motor1=90&motor2=80&motor3=70&motor4=60" http://localhost/run_pose/save_pose.php
curl -X POST -d "id=1" http://localhost/run_pose/update_status.php
curl -X GET http://localhost/run_pose/get_run_pose.php

🚀 2. Running the App
1.	Start XAMPP (Apache + MySQL)
2.	Run Flutter app:
flutter run
3.	Open emulator → Adjust sliders → Save Pose
4.	Check poses in database (phpMyAdmin)
5.	Tap Run button → Pose status updates

📂 Project Structure
run_pose_app/
 ├── lib/
 │    └── main.dart
 ├── pubspec.yaml
htdocs/
 └── run_pose/
      ├── save_pose.php
      ├── get_run_pose.php
      ├── update_status.php

🖼️ Screenshots
App UI
Database Table
Running on Emulator

📝 Diagram

✅ Completed Functions
•	Flutter app with sliders and buttons
•	PHP backend with MySQL integration
•	Save, fetch, update poses
•	Automatic status reset
•	Real-time slider updates

