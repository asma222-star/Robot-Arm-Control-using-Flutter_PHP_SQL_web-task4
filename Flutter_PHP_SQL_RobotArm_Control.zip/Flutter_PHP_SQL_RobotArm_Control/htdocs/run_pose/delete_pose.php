<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "run_pose_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "DB connection failed"]));
}

$id = $_POST['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM poses WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Pose deleted successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to delete pose"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "ID not provided"]);
}

$conn->close();
?>
