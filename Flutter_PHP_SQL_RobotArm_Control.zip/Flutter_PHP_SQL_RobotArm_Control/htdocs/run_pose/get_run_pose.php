<?php
// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'run_pose_db';

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Fetch data
$sql = "SELECT id, status, motor1, motor2, motor3, motor4 FROM poses";
$result = $conn->query($sql);

$poses = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $poses[] = $row;
    }
}

echo json_encode($poses);

$conn->close();
?>
