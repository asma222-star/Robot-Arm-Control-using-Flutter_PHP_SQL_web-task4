<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "run_pose_db");

// Check connection
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed"]));
}

// Validate POST data
if (!isset($_POST['motor1'], $_POST['motor2'], $_POST['motor3'], $_POST['motor4'])) {
    echo json_encode(["success" => false, "message" => "Missing motor values"]);
    exit;
}

$motor1 = intval($_POST['motor1']);
$motor2 = intval($_POST['motor2']);
$motor3 = intval($_POST['motor3']);
$motor4 = intval($_POST['motor4']);

// Insert data
$stmt = $conn->prepare("INSERT INTO poses (motor1, motor2, motor3, motor4, status) VALUES (?, ?, ?, ?, 0)");
$stmt->bind_param("iiii", $motor1, $motor2, $motor3, $motor4);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Pose saved successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to save pose"]);
}

$stmt->close();
$conn->close();
?>
