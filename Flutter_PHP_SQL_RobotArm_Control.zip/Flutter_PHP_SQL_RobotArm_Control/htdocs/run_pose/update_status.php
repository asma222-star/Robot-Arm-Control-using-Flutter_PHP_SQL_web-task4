<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "run_pose_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "DB connection failed"]));
}

$id = $_POST['id'] ?? null;
$m1 = $_POST['motor1'] ?? null;
$m2 = $_POST['motor2'] ?? null;
$m3 = $_POST['motor3'] ?? null;
$m4 = $_POST['motor4'] ?? null;

if ($id) {
    // Reset all poses to 0
    $conn->query("UPDATE poses SET status = 0");

    // Update selected pose to status 1 and real-time motor values
    $stmt = $conn->prepare("UPDATE poses SET status = 1, motor1 = ?, motor2 = ?, motor3 = ?, motor4 = ? WHERE id = ?");
    $stmt->bind_param("iiiii", $m1, $m2, $m3, $m4, $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Pose running and updated"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update status"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "ID or motor values missing"]);
}

$conn->close();
?>
