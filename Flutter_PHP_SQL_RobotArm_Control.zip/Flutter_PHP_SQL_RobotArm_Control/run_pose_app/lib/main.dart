import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Robot Arm Control Panel',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ControlPanelScreen(),
    );
  }
}

class ControlPanelScreen extends StatefulWidget {
  const ControlPanelScreen({super.key});

  @override
  _ControlPanelScreenState createState() => _ControlPanelScreenState();
}

class _ControlPanelScreenState extends State<ControlPanelScreen> {
  double motor1 = 90;
  double motor2 = 90;
  double motor3 = 90;
  double motor4 = 90;

  List poses = [];
  bool isLoading = true;

  final String baseUrl = "http://10.0.2.2/run_pose";

  @override
  void initState() {
    super.initState();
    fetchPoses();
  }

  Future<void> fetchPoses() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/get_run_pose.php"));
      if (response.statusCode == 200) {
        setState(() {
          poses = json.decode(response.body);
          isLoading = false;
        });
      } else {
        showMessage("Failed to load poses");
      }
    } catch (e) {
      showMessage("Error fetching poses: $e");
    }
  }

  Future<void> savePose() async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/save_pose.php"),
        body: {
          'motor1': motor1.toInt().toString(),
          'motor2': motor2.toInt().toString(),
          'motor3': motor3.toInt().toString(),
          'motor4': motor4.toInt().toString(),
        },
      );
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['success'] == true) {
          showMessage("Pose saved successfully");
          fetchPoses();
        } else {
          showMessage(result['message']);
        }
      }
    } catch (e) {
      showMessage("Error saving pose: $e");
    }
  }

  Future<void> runPose(int id) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/update_status.php"),
        body: {
          'id': id.toString(),
          'motor1': motor1.toInt().toString(),
          'motor2': motor2.toInt().toString(),
          'motor3': motor3.toInt().toString(),
          'motor4': motor4.toInt().toString(),
        },
      );
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['success'] == true) {
          showMessage("Pose $id is now running and updated");
          fetchPoses();
        } else {
          showMessage(result['message']);
        }
      }
    } catch (e) {
      showMessage("Error running pose: $e");
    }
  }

  Future<void> deletePose(int id) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/delete_pose.php"),
        body: {'id': id.toString()},
      );
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['success'] == true) {
          showMessage("Pose deleted successfully");
          fetchPoses();
        } else {
          showMessage(result['message']);
        }
      }
    } catch (e) {
      showMessage("Error deleting pose: $e");
    }
  }

  void resetSliders() {
    setState(() {
      motor1 = 90;
      motor2 = 90;
      motor3 = 90;
      motor4 = 90;
    });
  }

  void showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Robot Arm Control Panel')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            buildMotorSlider("Motor 1", motor1, (v) => setState(() => motor1 = v)),
            buildMotorSlider("Motor 2", motor2, (v) => setState(() => motor2 = v)),
            buildMotorSlider("Motor 3", motor3, (v) => setState(() => motor3 = v)),
            buildMotorSlider("Motor 4", motor4, (v) => setState(() => motor4 = v)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: resetSliders,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  child: const Text("Reset"),
                ),
                ElevatedButton(
                  onPressed: savePose,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("Save Pose"),
                ),
              ],
            ),
            const Divider(height: 30),
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : poses.isEmpty
                    ? const Text("No poses found")
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: poses.length,
                        itemBuilder: (context, index) {
                          final pose = poses[index];
                          final isRunning = pose['status'] == "1";
                          return Card(
                            color: isRunning ? Colors.lightGreen[100] : null,
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            child: ListTile(
                              title: Text(
                                "Pose ID: ${pose['id']}\n"
                                "M1: ${pose['motor1']} | "
                                "M2: ${pose['motor2']} | "
                                "M3: ${pose['motor3']} | "
                                "M4: ${pose['motor4']}",
                              ),
                              subtitle: Text("Status: ${pose['status']}"),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ElevatedButton(
                                    onPressed: () => runPose(int.parse(pose['id'])),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: isRunning
                                          ? Colors.green
                                          : Colors.blue,
                                    ),
                                    child: const Text("Run"),
                                  ),
                                  const SizedBox(width: 5),
                                  ElevatedButton(
                                    onPressed: () => deletePose(int.parse(pose['id'])),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red,
                                    ),
                                    child: const Icon(Icons.delete, color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: fetchPoses,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget buildMotorSlider(String label, double value, Function(double) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("$label: ${value.toInt()}°"),
        Slider(
          min: 0,
          max: 180,
          divisions: 180,
          value: value,
          label: value.toInt().toString(),
          onChanged: onChanged,
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
